#!/bin/bash

cat $OAR_FILE_NODES | sort | uniq > listNode;
rm -r __MACOSX/;

chmod 777 chainsend

cd chainsend;
make;
cd ..;

set -x

for n in $(cat listNode)
do
scp ~/.ssh/id_rsa root@${n}:.ssh/ > /dev/null
ssh-copy-id root@${n} > /dev/null
done