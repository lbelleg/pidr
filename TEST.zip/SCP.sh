#!/bin/bash
#Param 1 = nb node, 2 = fichier à envoyer
echo "Nb Node       : $1"
echo "Source        : $2"

time for n in $(tail -n $1 listNode)
do
scp $2 root@${n}:/tmp/
done