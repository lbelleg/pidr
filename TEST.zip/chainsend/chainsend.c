/*
 * chainsend.c - efficient (FSVO efficient) pipeline-based data broadcast
 * - Lucas Nussbaum <lucas.nussbaum@ens-lyon.fr>
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <getopt.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netdb.h>
#include <time.h>
#include <sys/time.h>
#include <errno.h>

#define NEXTNODES_MAX 10
#define BUFLEN (64*1024)

typedef struct {
	char * rhost;
	struct addrinfo *result;
	int fd;
	int nbytes;
} nextnode;

nextnode nextnodes[NEXTNODES_MAX];
int nextnodes_nb = 0;

char * output_file;
int output_fd = -1;
int output_fd_nbytes = 0;
int verbose = 0;
int listen_port = 50000;
int listen_fd;
int client_fd = -1;
int use_fsync = 0;
int print_stats = 0;

struct timeval tstart;
struct timeval tstartcopy;
struct timeval tinter;
struct timeval tres;

/* origin: glibc manual */
/**
 * this function is for computing the time difference between timeval x and y
 * the result is stored in result
 */
int timeval_substract(struct timeval *result, struct timeval *x, struct timeval *y)
{
        /* perform the carry for the later subtraction by updating y. */
        if (x->tv_usec < y->tv_usec) {
                int nsec = (y->tv_usec - x->tv_usec) / 1000000 + 1;
                y->tv_usec -= 1000000 * nsec;
                y->tv_sec += nsec;
        }
        if (x->tv_usec - y->tv_usec > 1000000) {
                int nsec = (x->tv_usec - y->tv_usec) / 1000000;
                y->tv_usec += 1000000 * nsec;
                y->tv_sec -= nsec;
        }

        /* compute the time remaining to wait.
           tv_usec is certainly positive. */
        result->tv_sec = x->tv_sec - y->tv_sec;
        result->tv_usec = x->tv_usec - y->tv_usec;

        /* return 1 if result is negative. */
        return x->tv_sec < y->tv_sec;
}

static char* default_port = "50000";

void parse_nextnodes()
{
	int i;
	char * hostn;
	char * hostp;
	int s;
	for (i = 0; i < nextnodes_nb; i++)
	{
		hostn = strdup(nextnodes[i].rhost);
		hostp = index(hostn, ':') + 1;
		if (hostp == NULL) {
			hostp = default_port;
		} else {
			*(hostp-1) = '\0';
		}

		struct addrinfo hints;

		memset(&hints, 0, sizeof(struct addrinfo));
		hints.ai_family = AF_INET;
		hints.ai_socktype = SOCK_STREAM; /* Datagram socket */
		hints.ai_flags = 0;
		hints.ai_protocol = 0;          /* Any protocol */

		s = getaddrinfo(hostn, hostp, &hints, &nextnodes[i].result);
		if (s != 0) {
			fprintf(stderr, "%s: %s\n", hostn, gai_strerror(s));
			exit(EXIT_FAILURE);
		}
		nextnodes[i].fd = -1;
	}
}

int main(int argc, char * argv[])
{
	int c;
	time_t now;
	double elapsed;

	while (1) {
		int option_index = 0;
		static struct option long_options[] = {
			{"next", 1, 0, 1},
			{"file", 1, 0, 2},
			{"stdout", 0, 0, 3},
			{"verbose", 0, 0, 4},
			{"port", 1, 0, 5},
			{"stdin", 0, 0, 6},
			{"fsync", 0, 0, 7},
			{"stats", 0, 0, 8},
			{0, 0, 0, 0}
		};

		c = getopt_long(argc, argv, "n:f:svp:yt",
				long_options, &option_index);
		if (c == -1)
			break;

		switch (c) {
			case 0:
				fprintf(stderr, "option %s", long_options[option_index].name);
				if (optarg)
					fprintf(stderr, " with arg %s", optarg);
				fprintf(stderr, "\n");
				break;


			case 1:
			case 'n':
				if (verbose)
					fprintf(stderr, "Adding next node: %s\n", optarg);
				nextnodes[nextnodes_nb].rhost = strdup(optarg);
				nextnodes_nb++;
				break;

			case 2:
			case 'f':
				output_file = strdup(optarg);
				if (verbose)
					fprintf(stderr, "Outputting to %s\n", output_file);
				output_fd = open(output_file, O_CREAT|O_WRONLY|O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
				if (output_fd == -1)
				{
					perror("Creating the output file failed:");
					exit(1);
				}
				if (fcntl(output_fd, F_SETFL, O_NONBLOCK) == -1)
				{
					perror("fcntl error: ");
					exit(1);
				}
				break;

			case 3:
			case 's':
				output_fd = STDOUT_FILENO;
				break;

			case 4:
			case 'v':
				verbose = 1;
				break;

			case 5:
			case 'p':
				listen_port = atoi(optarg);
				if (verbose)
					fprintf(stderr, "Will listen to %d\n", listen_port);
				break;

			case 6:
				client_fd = 0;
				if (verbose)
					fprintf(stderr, "Reading from stdin");
				break;

			case 7:
			case 'y':
				use_fsync = 1;
				if (verbose)
					fprintf(stderr, "Enabling fsync\n");
				break;

			case 8:
			case 't':
				print_stats = 1;
				if (verbose)
					fprintf(stderr, "Enabling stats generation\n");
				break;

			case '?':
				exit(1);

			default:
				fprintf(stderr, "?? getopt returned character code 0%o ??\n", c);
		}
	}

	if (optind < argc) {
		fprintf(stderr, "non-option ARGV-elements: ");
		while (optind < argc)
			printf("%s ", argv[optind++]);
		fprintf(stderr, "\n");
		exit(1);
	}

	if (output_fd == -1 && verbose)
		fprintf(stderr, "Note: no output method specified\n");

	if (verbose)
	{
		now = time(NULL);
		fprintf(stderr, "### 0 Finished option parsing, starting to connect. %s", ctime(&now));
	}
	if (print_stats)
		gettimeofday(&tstart, NULL);
	/* Parsing and resolving nextnodes */
	parse_nextnodes();
	/* Connecting everything */
	if (client_fd != 0)
	{
		if ((listen_fd = socket(PF_INET, SOCK_STREAM, 0)) == -1)
		{
			perror("socket error: ");
			exit(1);
		}

		if (fcntl(listen_fd, F_SETFL, O_NONBLOCK) == -1)
		{
			perror("fcntl error: ");
			exit(1);
		}

		int set_on = 1;
		setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &set_on, sizeof(set_on));

		struct sockaddr_in clientport;
		clientport.sin_family = AF_INET;
		clientport.sin_port = htons(listen_port);
		clientport.sin_addr.s_addr = INADDR_ANY;
		if (bind(listen_fd, (struct sockaddr *) &clientport, sizeof(struct sockaddr_in)) == -1)
		{
			perror("bind error: ");
			exit(1);
		}
		if (listen(listen_fd, 2) == -1)
		{
			perror("listen error: ");
			exit(1);
		}
	}
	int ok = 0;
	struct sockaddr_in clientaddr;
	int len = sizeof(struct sockaddr_in);
	while (!ok)
	{
		ok = 1;
		/* Try to accept */
		if (client_fd == -1)
		{
			if ((client_fd = accept(listen_fd, (struct sockaddr *) &clientaddr, (socklen_t *) &len))==-1){
				if (errno != EAGAIN && errno != EWOULDBLOCK)
					perror("accept: ");
				ok = 0;
			} else
			if (verbose) {
				char* repr = inet_ntoa(clientaddr.sin_addr);
				fprintf(stderr, "### Connection from %s.\n", repr);
			}
		}
		int i;
		struct addrinfo *rp;
		for (i = 0; i < nextnodes_nb; i++)
		{
			if (nextnodes[i].fd != -1)
				continue;

			for (rp = nextnodes[i].result; rp != NULL; rp = rp->ai_next)
			{
				nextnodes[i].fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
				if (nextnodes[i].fd == -1)
					continue;

				if (connect(nextnodes[i].fd, rp->ai_addr, rp->ai_addrlen) != -1)
				{
					if (fcntl(nextnodes[i].fd, F_SETFL, O_NONBLOCK) == -1)
					{
						perror("fcntl error: ");
						exit(1);
					}
					break;
				}

				if (errno != ECONNREFUSED)
					perror("connect: ");
				close(nextnodes[i].fd);
				nextnodes[i].fd = -1;
			}
			if (rp == NULL) {               /* No address succeeded */
				ok = 0;
			}
		}
	}

	if (verbose)
		fprintf(stderr, "### Everybody connected.\n");

	if (print_stats) {
		gettimeofday(&tinter, NULL);
		timeval_substract(&tres, &tinter, &tstart);
		elapsed = tres.tv_sec + ((double) tres.tv_usec) / 1000000;

		if (verbose)
			fprintf(stderr, "### %f All nodes connected! Starting copy.\n", elapsed);

		gettimeofday(&tstartcopy, NULL);
	}

	char buf[BUFLEN];
	int n, n2;
	int i;
	unsigned long long totlen = 0;
	
	while(1)
	{
		n = read(client_fd, buf, BUFLEN);
		totlen += n;
		if (n == 0)
			break;
		if (n == 1)
		{
			perror("read: ");
			exit(1);
		}
		for (i = 0; i < nextnodes_nb; i++)
			nextnodes[i].nbytes = 0;
		output_fd_nbytes = 0;
		int done = 0;
		while (!done)
		{
			done = 1;
			for (i = 0; i < nextnodes_nb; i++)
			{
				/* Continue if all bytes written */
				if (nextnodes[i].nbytes == n)
					continue;

				n2  = write(nextnodes[i].fd, buf + nextnodes[i].nbytes, n - nextnodes[i].nbytes);
				if (n2  == -1)
				{
					if (errno != EAGAIN)
					{
						perror("write: ");
						exit(1);
					}
					else
					{
						n2 = 0;
					}
				}

				if (n2 != n - nextnodes[i].nbytes)
				{
					if (n2 > 0 && verbose)
						fprintf(stderr, "Only %d bytes written ; %d expected\n", n2, n);
					done = 0;
				}
				nextnodes[i].nbytes += n2;
			}
			if (output_fd != -1 && output_fd_nbytes != n)
			{
				n2  = write(output_fd, buf + output_fd_nbytes, n - output_fd_nbytes);
				//printf("%d\n", n2);
				if (n2  == -1)
				{
					if (errno != EAGAIN)
					{
						perror("write: ");
						exit(1);
					}
					else
					{
						n2 = 0;
					}
				}
				if (n2 != n - output_fd_nbytes)
				{
					if (n2 > 0 && verbose)
						fprintf(stderr, "Only %d bytes written ; %d expected\n", n2, n);
					done = 0;
				}
				output_fd_nbytes += n2;
			}
		}

	}

	/* properly shutdown connection */
	if (listen_fd != -1)
		close(listen_fd);

	if (client_fd != 0)
	{
		if (shutdown(client_fd, SHUT_RDWR) == -1)
		{
			perror("shutdown error: ");
			exit(1);
		}
		close(client_fd);
	}
	for (i = 0; i < nextnodes_nb; i++)
	{
		if (shutdown(nextnodes[i].fd, SHUT_RDWR) == -1)
		{
			perror("shutdown error: ");
			exit(1);
		}
		close(nextnodes[i].fd);
	}

	if (print_stats) {
		gettimeofday(&tinter, NULL);
		timeval_substract(&tres, &tinter, &tstartcopy);
		elapsed = tres.tv_sec + ((double) tres.tv_usec) / 1000000;
		if (verbose)
			fprintf(stderr, "### %f %llu bytes (Avg %.2f MB/s); copy finished (before fsync).\n", elapsed, totlen, (double) totlen / elapsed / 1024 / 1024);
	}

	if (output_fd != -1)
	{
		if (use_fsync)
			fsync(output_fd);
		close(output_fd);
	}

	if (print_stats) {
		gettimeofday(&tinter, NULL);
		timeval_substract(&tres, &tinter, &tstartcopy);
		elapsed = tres.tv_sec + ((double) tres.tv_usec) / 1000000;
		if (verbose)
			fprintf(stderr, "### %f %llu bytes (Avg %.2f MB/s); copy finished.\n", elapsed, totlen, (double) totlen / elapsed / 1024 / 1024);
	}

	exit(EXIT_SUCCESS);
}
